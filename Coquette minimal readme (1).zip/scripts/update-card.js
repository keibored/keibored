// Updates assets/keibored-card.svg with live GitHub language stats. Runs in GitHub Actions.
const fs = require('fs');
const USER = process.env.GH_USER || 'keibored';
const TOKEN = process.env.GITHUB_TOKEN;
const H = { 'User-Agent': 'card-updater', ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}) };

async function gh(path) {
  const r = await fetch('https://api.github.com' + path, { headers: H });
  if (!r.ok) throw new Error(path + ' -> ' + r.status);
  return r.json();
}
const setText = (svg, id, val) =>
  svg.replace(new RegExp('(<text[^>]*id="' + id + '"[^>]*>)[^<]*(</text>)'), '$1' + val + '$2');
const setBar = (svg, id, pct) =>
  svg.replace(new RegExp('(<rect[^>]*id="' + id + '"[^>]*width=")[0-9.]+(")'), '$1' + (272 * pct / 100).toFixed(0) + '$2');

(async () => {
  const repos = await gh('/users/' + USER + '/repos?per_page=100&type=owner');
  const langTotals = {};
  for (const r of repos.filter(r => !r.fork).slice(0, 30)) {
    try {
      const langs = await gh('/repos/' + USER + '/' + r.name + '/languages');
      for (const [k, v] of Object.entries(langs)) langTotals[k] = (langTotals[k] || 0) + v;
    } catch {}
  }
  const totalBytes = Object.values(langTotals).reduce((a, b) => a + b, 0) || 1;
  const top = Object.entries(langTotals).sort((a, b) => b[1] - a[1]).slice(0, 3);

  let svg = fs.readFileSync('assets/keibored-card.svg', 'utf8');
  top.forEach(([name, bytes], i) => {
    const pct = Math.round(bytes / totalBytes * 100);
    svg = setText(svg, 'lang' + (i + 1) + 'Name', name);
    svg = setText(svg, 'lang' + (i + 1) + 'Pct', pct + '%');
    svg = setBar(svg, 'lang' + (i + 1) + 'Bar', pct);
  });
  fs.writeFileSync('assets/keibored-card.svg', svg);
  console.log('card updated:', top.map(t => t[0]).join(', '));
})();
